const submitBtn = document.querySelector("#submit-btn");

submitBtn.addEventListener("click", function (event) {
  event.preventDefault(); 

  var users = {};
  var storedUsers = localStorage.getItem("users");
  if (storedUsers) {
    users = JSON.parse(storedUsers);
  }

  // obter valores do formulário
  const newUsername = document.querySelector("#newUsername").value;
  const newEmail = document.querySelector("#newEmail").value;
  const newCidade = document.querySelector("#newCidade").value;
  const newEndereco = document.querySelector("#newEndereco").value;
  const newContato = document.querySelector("#newContato").value;
  const newAtuacao = document.querySelector("#newAtuacao").value;
  const newPassword = document.querySelector("#newPassword").value;
  const newConfirmPassword = document.querySelector("#newConfirm-password").value;

  // validar campos do formulário
  if (!newUsername || !newEmail || !newCidade || !newEndereco || !newContato || !newAtuacao || !newPassword || !newConfirmPassword) {
    alert("Por favor, preencha todos os campos.");
    return;
  }

  if (newPassword !== newConfirmPassword) {
    alert("As senhas não coincidem.");
    return;
  }

  if (!document.querySelector("#terms").checked) {
    alert("Por favor, concorde com os Termos de Segurança.");
    return;
  }

  if (!document.querySelector("#privacy").checked) {
    alert("Por favor, aceite a Política de Privacidade.");
    return;
  }

  // armazenar dados do usuário no objeto "users"
  users.newUsername = newUsername;
  users.newEmail = newEmail;
  users.newCidade = newCidade;
  users.newEndereco = newEndereco;
  users.newContato = newContato;
  users.newAtuacao = newAtuacao;
  users.newPassword = newPassword;

  // salvar o objeto "users" no localStorage
  localStorage.setItem("users", JSON.stringify(users));

  // resetar o formulário
  document.querySelector("form").reset();

  // exibir mensagem de sucesso
  alert("Cadastro realizado com sucesso!");

  // redirecionar o usuário para a página de login
  window.location.href = "user.html";
});


 /* cabeçalho*/

 class MobileNavbar {
  constructor(mobileMenu, navList, navLinks) {
    this.mobileMenu = document.querySelector(mobileMenu);
    this.navList = document.querySelector(navList);
    this.navLinks = document.querySelectorAll(navLinks);
    this.activeClass = "active";

    this.handleClick = this.handleClick.bind(this);
  }

  animateLinks() {
    this.navLinks.forEach((link, index) => {
      link.style.animation
        ? (link.style.animation = "")
        : (link.style.animation = `navLinkFade 0.5s ease forwards ${
            index / 7 + 0.3
          }s`);
    });
  }

  handleClick() {
    this.navList.classList.toggle(this.activeClass);
    this.mobileMenu.classList.toggle(this.activeClass);
    this.animateLinks();
  }

  addClickEvent() {
    this.mobileMenu.addEventListener("click", this.handleClick);
  }

  init() {
    if (this.mobileMenu) {
      this.addClickEvent();
    }
    return this;
  }
}

const mobileNavbar = new MobileNavbar(
  ".mobile-menu",
  ".nav-list",
  ".nav-list li",
);
mobileNavbar.init();

/* fim cabecalho*/


