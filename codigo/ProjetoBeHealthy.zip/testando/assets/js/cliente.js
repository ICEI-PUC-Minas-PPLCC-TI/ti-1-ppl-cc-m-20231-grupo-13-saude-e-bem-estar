document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('myForm').addEventListener('submit', function(e) {
    e.preventDefault();

    var formData = new FormData(this);
    var jsonData = {};

    for (var pair of formData.entries()) {
      jsonData[pair[0]] = pair[1];
    }

    localStorage.setItem('jsonData', JSON.stringify(jsonData));

    let jsonDataObj = JSON.parse(localStorage.getItem('jsonData'));

    displayData(jsonDataObj);

    alert('Dados enviados com sucesso!');

    this.reset();
  });

  // Função para exibir os dados salvos na página
  function displayData(data) {
    var dataList = document.getElementById('dataList');
    var dataItem = document.createElement('div');
    dataItem.className = 'data-list';

    for (var key in data) {
      if (data.hasOwnProperty(key)) {
        var p = document.createElement('p');
        p.textContent = key + ': ' + data[key];
        dataItem.appendChild(p);
      }
    }

    var deleteButton = document.createElement('button');
    deleteButton.textContent = 'Excluir';
    deleteButton.addEventListener('click', function() {
      deleteData(data);
      dataList.removeChild(dataItem);
      alert('Dados excluídos com sucesso!');
    });
    dataItem.appendChild(deleteButton);

    dataList.appendChild(dataItem);
  }

  // Função para excluir dados do localStorage
  function deleteData(data) {
    localStorage.removeItem('jsonData');
  }

  // Carregar dados salvos do localStorage ao carregar a página
  var jsonDataString = localStorage.getItem('jsonData');
  if (jsonDataString) {
    var jsonDataObj = JSON.parse(jsonDataString);
    displayData(jsonDataObj);
  }
});