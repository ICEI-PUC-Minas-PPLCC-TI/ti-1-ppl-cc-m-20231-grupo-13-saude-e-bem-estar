/* login*/



// selecione o botão de envio
const submitBtn2 = document.querySelector("#submit-btn2");

// adicione um evento de clique ao botão de envio
submitBtn2.addEventListener("click", function(event) {
  event.preventDefault(); // previne o envio do formulário padrão
  
  // selecione os campos de usuário e senha
  const username2 = document.getElementById("username");
  const password2 = document.getElementById("password");

  // recuperar dados do localStorage
const storedUsers = localStorage.getItem("users");
if (!storedUsers) {
  alert("Nenhum usuário cadastrado. Por favor, cadastre-se primeiro.");
  return;
}
const users = JSON.parse(storedUsers);
const storedUsername = users.newUsername;
const storedPassword = users.newPassword;


  // verifique se ambos os campos estão preenchidos e correspondem aos dados armazenados
if (!username2.value || !password2.value || username2.value !== storedUsername || password2.value !== storedPassword) {
  alert("As informações de login estão incorretas. Por favor, tente novamente.");
  return;
} else {
  // o usuário preencheu todos os campos corretamente, então pode fazer login
alert("Login bem-sucedido!");

// redirecionar o usuário para a página de destino do login
window.location.href = "home.html";
}



});
