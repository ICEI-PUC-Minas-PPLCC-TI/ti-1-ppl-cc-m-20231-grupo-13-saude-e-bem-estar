    
    window.addEventListener('DOMContentLoaded', function () {
        var cards = JSON.parse(localStorage.getItem('cards')) || [];
        var cardSection = document.getElementById('card-section');
  
        cards.forEach(function (cardData) {
          var card = createCard(cardData);
          cardSection.appendChild(card);
        });
      });
  
      document.querySelector('#myForm').addEventListener('submit', function (e) {
        e.preventDefault();
  
        var nome = document.getElementById('nome').value;
        var areaAtuacao = document.getElementById('area-atuacao').value;
        var localizacao = document.getElementById('localizacao').value;
        var descricao = document.getElementById('descricao').value;
  
        var cardData = {
          nome: nome,
          areaAtuacao: areaAtuacao,
          localizacao: localizacao,
          descricao: descricao
        };
  
        var cardSection = document.getElementById('card-section');
        var card = createCard(cardData);
        cardSection.appendChild(card);
  
        
        var cards = JSON.parse(localStorage.getItem('cards')) || [];
        cards.push(cardData);
        localStorage.setItem('cards', JSON.stringify(cards));
  
        
        document.getElementById('nome').value = '';
        document.getElementById('area-atuacao').value = '';
        document.getElementById('localizacao').value = '';
        document.getElementById('descricao').value = '';
      });
  
      function createCard(cardData) {
        var card = document.createElement('div');
        card.className = 'col-md-6';
        card.innerHTML = `
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">${cardData.nome}</h5>
              <h6 class="card-subtitle mb-2 text-muted">${cardData.localizacao} | ${cardData.areaAtuacao}</h6>
              <p class="card-text">${cardData.descricao}</p>
              <button class="btn btn-danger" onclick="deleteCard(this)">Excluir</button>
            </div>
          </div>
        `;
  
        return card;
      }
  
      function deleteCard(button) {
        var card = button.closest('.card');
        card.remove();
  
        
        var cards = JSON.parse(localStorage.getItem('cards')) || [];
        var cardData = {
          nome: card.querySelector('.card-title').textContent,
          areaAtuacao: card.querySelector('.card-subtitle').textContent.split('|')[1].trim(),
          localizacao: card.querySelector('.card-subtitle').textContent.split('|')[0].trim(),
          descricao: card.querySelector('.card-text').textContent
        };
        var index = cards.findIndex(function (c) {
          return c.nome === cardData.nome && c.areaAtuacao === cardData.areaAtuacao && c.localizacao === cardData.localizacao && c.descricao === cardData.descricao;
        });
        if (index > -1) {
          cards.splice(index, 1);
          localStorage.setItem('cards', JSON.stringify(cards));
        }
      }