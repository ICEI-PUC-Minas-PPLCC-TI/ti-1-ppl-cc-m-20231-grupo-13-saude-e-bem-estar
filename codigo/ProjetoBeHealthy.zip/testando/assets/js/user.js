document.addEventListener("DOMContentLoaded", function() {
    // Recupere os dados do local storage
    var storedUsers = localStorage.getItem("users");
    if (storedUsers) {
      var users = JSON.parse(storedUsers);

      // Atribua os valores aos elementos HTML correspondentes
      document.getElementById("newUsername").textContent = users.newUsername;
      document.getElementById("newEmail").textContent = users.newEmail;
      document.getElementById("newCidade").textContent = users.newCidade;
      document.getElementById("newEndereco").textContent = users.newEndereco;
      document.getElementById("newContato").textContent = users.newContato;
      
    }
  });

  function enableEdit(...elementIds) {
    elementIds.forEach(function(elementId) {
      var element = document.getElementById(elementId);
      var buttons = document.querySelectorAll(`.btn-edit-${elementId}`);
  
      element.contentEditable = true;
      element.focus();
  
      buttons.forEach(function(button) {
        button.style.display = "none";
      });
      var saveButton = document.createElement("button");
      saveButton.textContent = "Salvar Alterações";
      saveButton.className = `btn-save-${elementId}`;
      saveButton.onclick = function() {
        saveChanges(elementId);
      };
    
      button.parentNode.insertBefore(saveButton, button.nextSibling);
    });
  }
  
  function saveChanges(elementId) {
    var element = document.getElementById(elementId);
    var editButton = document.querySelector(`.btn-edit-${elementId}`);
    var saveButton = document.querySelector(`.btn-save-${elementId}`);
  
    element.contentEditable = false;
    editButton.style.display = "inline-block";
    saveButton.parentNode.removeChild(saveButton);
  }
  
  
  
  

  /* cabeçalho*/

  class MobileNavbar {
    constructor(mobileMenu, navList, navLinks) {
      this.mobileMenu = document.querySelector(mobileMenu);
      this.navList = document.querySelector(navList);
      this.navLinks = document.querySelectorAll(navLinks);
      this.activeClass = "active";
  
      this.handleClick = this.handleClick.bind(this);
    }
  
    animateLinks() {
      this.navLinks.forEach((link, index) => {
        link.style.animation
          ? (link.style.animation = "")
          : (link.style.animation = `navLinkFade 0.5s ease forwards ${
              index / 7 + 0.3
            }s`);
      });
    }
  
    handleClick() {
      this.navList.classList.toggle(this.activeClass);
      this.mobileMenu.classList.toggle(this.activeClass);
      this.animateLinks();
    }
  
    addClickEvent() {
      this.mobileMenu.addEventListener("click", this.handleClick);
    }
  
    init() {
      if (this.mobileMenu) {
        this.addClickEvent();
      }
      return this;
    }
  }
  
  const mobileNavbar = new MobileNavbar(
    ".mobile-menu",
    ".nav-list",
    ".nav-list li",
  );
  mobileNavbar.init();

  /* fim cabecalho*/
